package pacman;

/**
 * User: Simon
 * Date: 13-Oct-2007
 * Time: 22:37:26
 */
public interface PacAgent {
    public int move(GameState gs);
}
