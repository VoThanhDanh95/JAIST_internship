package pacman;

/**
 * User: Simon
 * Date: 13-Oct-2007
 * Time: 18:48:51
 */
public class Plan {
    // the idea of this class is to follow a pre-planned route
    // where the route would consist of a set of waypoints
}
