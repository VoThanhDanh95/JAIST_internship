package pacman;

/**
 * User: Simon
 * Date: 08-Mar-2007
 * Time: 15:50:53
 */
public class ColTest {
    public static void main(String[] args) {
        System.out.println(MsPacInterface.pill);
        System.out.println(MsPacInterface.pill & 0xFFFFFF);
        System.out.println(0xFF000000);
    }
}
