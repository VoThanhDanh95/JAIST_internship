package game.controllers.ghosts.game;

import game.core.Game;

public class GameGhostFrightenedState implements GameGhostAI {

	@Override
	public int[] execute(int ghostType, Game game, long timeDue) {
		return null;
	}

}
