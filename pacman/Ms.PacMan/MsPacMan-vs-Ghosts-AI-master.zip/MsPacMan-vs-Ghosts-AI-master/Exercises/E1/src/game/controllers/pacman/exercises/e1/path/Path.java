package game.controllers.pacman.exercises.e1.path;

import game.controllers.pacman.exercises.e1.graph.Node;


public class Path {

	public final Node[] path;
	
	public Path(Node... path) {
		this.path = path;
	}
	
}
