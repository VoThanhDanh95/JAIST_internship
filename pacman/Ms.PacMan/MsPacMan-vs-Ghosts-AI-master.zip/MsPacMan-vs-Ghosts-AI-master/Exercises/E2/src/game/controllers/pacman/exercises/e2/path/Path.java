package game.controllers.pacman.exercises.e2.path;

import game.controllers.pacman.exercises.e2.graph.Node;


public class Path {

	public final Node[] path;
	
	public Path(Node... path) {
		this.path = path;
	}
	
}
