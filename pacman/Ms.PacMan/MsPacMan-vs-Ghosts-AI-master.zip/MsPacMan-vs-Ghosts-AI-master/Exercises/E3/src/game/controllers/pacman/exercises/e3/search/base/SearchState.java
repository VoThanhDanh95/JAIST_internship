package game.controllers.pacman.exercises.e3.search.base;

public enum SearchState {

	NONE,
	RUNNING,
	PATH_FOUND,
	FAILED
	
}
