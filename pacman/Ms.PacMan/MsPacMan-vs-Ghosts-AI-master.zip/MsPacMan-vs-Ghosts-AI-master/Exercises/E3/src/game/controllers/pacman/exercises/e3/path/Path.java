package game.controllers.pacman.exercises.e3.path;

import game.controllers.pacman.exercises.e3.graph.Node;


public class Path {

	public final Node[] path;
	
	public Path(Node... path) {
		this.path = path;
	}
	
}
